import SwiftUI

/// سرویس‌های پرکاربرد برای نمایش (شناسه پایدار بر اساس نام)
struct ServiceCount: Identifiable {
    let name: String
    let count: Int
    var id: String { name }
}

struct ContentView: View {
    @StateObject private var engine = FlooderEngine()

    var body: some View {
        TabView {
            ControlView(engine: engine)
                .tabItem { Label("حمله", systemImage: "bolt.fill") }
            ServicesView(engine: engine)
                .tabItem { Label("سرویس‌ها", systemImage: "list.bullet.rectangle") }
            AboutView()
                .tabItem { Label("درباره", systemImage: "info.circle") }
        }
        .environment(\.layoutDirection, .rightToLeft)
        .preferredColorScheme(.dark)
    }
}

// MARK: - صفحه کنترل حمله

struct ControlView: View {
    @ObservedObject var engine: FlooderEngine

    private var topServices: [ServiceCount] {
        engine.stats.servicesUsed
            .sorted { $0.value > $1.value }
            .prefix(5)
            .map { ServiceCount(name: $0.key, count: $0.value) }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    numberCard
                    settingsCard
                    startButton
                    statsGrid
                    topServicesCard
                }
                .padding()
            }
            .navigationTitle("SMS Flooder")
        }
    }

    private var numberCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("شماره هدف")
                .font(.headline)
            TextField("مثلاً ۰۹۱۲۱۲۳۴۵۶۷", text: $engine.target)
                .keyboardType(.phonePad)
                .autocorrectionDisabled()
                .textFieldStyle(.roundedBorder)
                .disabled(engine.isRunning)
        }
        .card()
    }

    private var settingsCard: some View {
        VStack(spacing: 14) {
            Stepper(value: $engine.threads, in: 1...200) {
                label("تعداد نخ‌ها", value: "\(engine.threads)")
            }
            .disabled(engine.isRunning)

            Stepper(value: $engine.delay, in: 0...2, step: 0.01) {
                label("تأخیر (ثانیه)", value: String(format: "%.2f", engine.delay))
            }
            .disabled(engine.isRunning)

            Stepper(value: $engine.maxMessages, in: 0...100_000, step: 10) {
                label(
                    "سقف پیام‌ها",
                    value: engine.maxMessages == 0 ? "نامحدود" : "\(engine.maxMessages)"
                )
            }
            .disabled(engine.isRunning)
        }
        .card()
    }

    private func label(_ title: String, value: String) -> some View {
        HStack {
            Text(title)
            Spacer()
            Text(value)
                .foregroundColor(.secondary)
                .monospacedDigit()
        }
    }

    private var startButton: some View {
        Button {
            if engine.isRunning {
                engine.stop()
            } else {
                engine.start()
            }
        } label: {
            Label(
                engine.isRunning ? "توقف" : "شروع حمله",
                systemImage: engine.isRunning ? "stop.circle.fill" : "play.circle.fill"
            )
            .font(.headline)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 6)
        }
        .buttonStyle(.borderedProminent)
        .tint(engine.isRunning ? .red : .green)
    }

    private var statsGrid: some View {
        VStack(spacing: 10) {
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                StatCell(title: "موفق", value: "\(engine.stats.sent)")
                StatCell(title: "ناموفق", value: "\(engine.stats.failed)")
                StatCell(title: "مجموع", value: "\(engine.stats.total)")
                StatCell(title: "نرخ", value: String(format: "%.1f", engine.stats.rate))
            }
            Text("زمان: \(String(format: "%.1f", engine.stats.elapsed)) ثانیه")
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }

    @ViewBuilder
    private var topServicesCard: some View {
        if !topServices.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                Text("سرویس‌های پرکاربرد")
                    .font(.subheadline.bold())
                ForEach(topServices) { item in
                    HStack {
                        Text(item.name)
                        Spacer()
                        Text("\(item.count)")
                            .foregroundColor(.secondary)
                            .monospacedDigit()
                    }
                    .font(.caption)
                }
            }
            .card()
        }
    }
}

struct StatCell: View {
    let title: String
    let value: String

    var body: some View {
        VStack(spacing: 6) {
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
            Text(value)
                .font(.title3.bold())
                .monospacedDigit()
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(.secondarySystemBackground)))
    }
}

// MARK: - صفحه درباره

struct AboutView: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    aboutCard(
                        title: "هشدار قانونی",
                        icon: "exclamationmark.triangle.fill",
                        color: .orange,
                        text: "این ابزار فقط برای تست نفوذ مجاز و ارزیابی امنیتی سامانه‌های تحت مالکیت یا دارای مجوز کتبی طراحی شده است. هرگونه استفاده نادرست غیرقانونی است و مسئولیت آن بر عهده کاربر است."
                    )
                    aboutCard(
                        title: "محدودیت‌های iOS",
                        icon: "iphone.slash",
                        color: .blue,
                        text: "iOS اجازه اجرای بی‌وقفه در پس‌زمینه را نمی‌دهد؛ بنابراین اجرای حمله فقط در حالت پیش‌زمینه (فورگراند) تضمین می‌شود. هنگام اجرا، صفحه را روشن و برنامه را باز نگه دارید."
                    )
                    aboutCard(
                        title: "امکانات",
                        icon: "checkmark.seal.fill",
                        color: .green,
                        text: "۶۰ سرویس OTP ایرانی، هدرهای تصادفی، قالب‌بندی خودکار شماره (۰۹۱۲ / ۹۸۹۱۲ / +۹۸۹۱۲)، آمار زنده، کنترل همزمانی و تأخیر، سقف پیام، و تست ۱۰ سرویس اول."
                    )
                }
                .padding()
            }
            .navigationTitle("درباره")
        }
    }

    private func aboutCard(title: String, icon: String, color: Color, text: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(color)
            VStack(alignment: .leading, spacing: 6) {
                Text(title)
                    .font(.headline)
                Text(text)
                    .font(.callout)
                    .foregroundColor(.secondary)
            }
        }
        .card()
    }
}

// MARK: - کارت مشترک

extension View {
    func card() -> some View {
        self
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: 14)
                    .fill(Color(.secondarySystemBackground))
            )
    }
}
