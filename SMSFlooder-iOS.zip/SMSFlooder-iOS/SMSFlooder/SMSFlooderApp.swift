import SwiftUI

@main
struct SMSFlooderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
