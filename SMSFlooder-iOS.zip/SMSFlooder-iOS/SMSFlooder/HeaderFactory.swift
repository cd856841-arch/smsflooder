import Foundation

/// ساخت هدرهای تصادفی مشابه نسخه پایتونی ابزار
enum HeaderFactory {
    static let userAgents = [
        "Mozilla/5.0 (Linux; Android 14; Pixel 9 Pro) AppleWebKit/537.36",
        "Mozilla/5.0 (Linux; Android 13; Samsung Galaxy S24) AppleWebKit/537.36",
        "Mozilla/5.0 (Linux; Android 14; Xiaomi 14 Pro) AppleWebKit/537.36",
        "Mozilla/5.0 (Linux; Android 12; OnePlus 11) AppleWebKit/537.36",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15",
        "Dalvik/2.1.0 (Linux; U; Android 14; Pixel 8 Build/UQ1A)",
        "okhttp/4.12.0",
        "Dalvik/2.1.0 (Linux; U; Android 13; SM-S918B Build/TP1A)",
    ]

    static let languages = [
        "fa-IR,fa;q=0.9,en;q=0.8",
        "en-US,en;q=0.9",
        "ar-SA,ar;q=0.9,en;q=0.8",
    ]

    static let requestedWith = [
        "XMLHttpRequest",
        "com.snapp.passenger",
        "ir.divar",
        "com.tapsi.cab",
    ]

    static let origins = [
        "https://snapp.ir",
        "https://divar.ir",
        "https://www.alibaba.ir",
        "https://tapsi.ir",
    ]

    static let referers = [
        "https://snapp.ir/",
        "https://divar.ir/",
        "https://www.alibaba.ir/",
        "https://tapsi.ir/",
    ]

    static func randomHeaders() -> [String: String] {
        [
            "User-Agent": userAgents.randomElement() ?? userAgents[0],
            "Accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": languages.randomElement() ?? languages[0],
            "Connection": "keep-alive",
            "Content-Type": "application/json",
            "X-Requested-With": requestedWith.randomElement() ?? requestedWith[0],
            "Origin": origins.randomElement() ?? origins[0],
            "Referer": referers.randomElement() ?? referers[0],
        ]
    }
}
