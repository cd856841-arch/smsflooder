import SwiftUI

/// فهرست سرویس‌ها با قابلیت فعال/غیرفعال کردن و تست اندپوینت‌ها
struct ServicesView: View {
    @ObservedObject var engine: FlooderEngine

    private var activeCount: Int {
        engine.services.filter { $0.active }.count
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Button {
                        Task.detached { await engine.testEndpoints() }
                    } label: {
                        Label("تست ۱۰ سرویس اول", systemImage: "bolt.horizontal.circle")
                    }
                    .disabled(engine.isRunning)

                    if !engine.lastMessage.isEmpty {
                        Text(engine.lastMessage)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                } header: {
                    Text("آزمون اتصال")
                }

                Section {
                    ForEach($engine.services) { $service in
                        Toggle(isOn: $service.active) {
                            Text(service.name)
                        }
                    }
                } header: {
                    Text("سرویس‌ها (\(activeCount) فعال از \(engine.services.count))")
                }
            }
            .navigationTitle("سرویس‌ها")
        }
    }
}
